package Immutable;

import java.util.HashMap;
import java.util.Map;
 final class Student {
  private String name;  // variable are not final thats why when ever constructor called new value be added to that variable
     // make it final to the variable to become immutable class
  private int number;


     public Student(String name, int number) {
         this.name = name;
         this.number = number;
     }

     public String getName() {
         return name;
     }

     public void setName(String name) {// because of setter method class become mutable class to change this to immutable class
         // remove setter method
         this.name = name;
     }

     public int getNumber() {
         return number;
     }

     public void setNumber(int number) {
         this.number = number;
     }

     @Override
     public String toString() {
         return "Student{" +
                 "name='" + name + '\'' +
                 ", number=" + number +
                 '}';
     }
 }
class SingleOne {
    public static void main(String[] args)
    {
    Student student=new Student("aa",1);
        System.out.println(student.toString());
        student.setNumber(2);// because set method the values has been changed
        student.setName("prem");

        System.out.println(student.toString());

    }
}


// Removing Setter method
final class StudentTwo {
    final private String name;  // i have made changes to variable to final , now the values cannot change its value
   final private int number;
    final private  A a;

    public StudentTwo(String name, int number, A a) {
        this.name = name;
        this.number = number;
        this.a=a;
    }

    public String getName() {
        return name;
    }
    public A getA() {
        return a;
    }

  /*  public void setName(String name) {//
        // now setter raising compiler error that for final variable we cannot use setter method because cant  be changable
        this.name = name;
    }*/

    public int getNumber() {
        return number;
    }

    @Override
    public String toString() {
        return "StudentTwo{" +
                "name='" + name + '\'' +
                ", number=" + number +
                ", a=" + a +
                '}';
    }

/*
    public void setNumber(int number) {
        this.number = number;
    }
*/


}
class A
{

    private int pincode;
    private  String area;


    public A(int pincode, String area) {
        this.pincode = pincode;
        this.area = area;
    }

    public int getPincode() {
        return pincode;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return "A{" +
                "pincode=" + pincode +
                ", area='" + area + '\'' +
                '}';
    }
}
class ImmutableTwo{
    public static void main(String[] args)
    {
        A a=new A(1,"hyderabad");
        StudentTwo student=new StudentTwo("aa",1, a);
        System.out.println(student.toString());
        a.setArea("pune");
        a.setPincode(20035);
        System.out.println(student.toString());
     /*   student.setNumber(2);// Now there no option to setting vaues to the final variable
        student.setName("prem");*/
   //A a=new A();

       // System.out.println(student.toString());

    }
}